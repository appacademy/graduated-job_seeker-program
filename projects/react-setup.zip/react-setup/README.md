### Setup
1. Run npm install
2. Run webpack
3. Open index.html
